/* -*- C++ -*- */
//just because the arduino IDE is not supporting .hpp files
//and because i need the original menu.h to include all arduino stuff
//including files not compatible with esp8266

#include "menu.hpp"
#include "dev/serialOut.hpp"
//#include "dev/htmlOut.hpp"
