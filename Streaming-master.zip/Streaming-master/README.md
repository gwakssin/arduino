Fork of Mikal Hart Streaming library.

Implements C++ Streaming operator (<<) for various print operations.

Changes in this fork include:

1) Updated for Arduino 1.0
2) Changed macro 'BIN' to 'BINARY' to be compatible with ATtiny.
  NB: The define of 'BIN' in Print.h must be similarly changed to use this library

